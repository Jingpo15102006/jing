#include <stdio.h>
#include <string.h>
int main (){
    int x1,x2,x3,y1,y2,y3;
    float area;
    printf("Enter coordinate x and y of point A:");
    scanf("%d %d",&x1,&y1);
    printf("Enter coordinate x and y of point B:");
    scanf("%d %d",&x2,&y2);
    printf("Enter coordinate x and y of point C:");
    scanf("%d %d",&x3,&y3);

    area = 0.5*(x1*(y2-y3)+x2*(y3-y1)+x3*(y1-y2));
        printf("The area of this triangle with point A(%d,%d), B(%d,%d) and C(%d,%d) is %.2f square units.",x1,y1,x2,y2,x3,y3,area);
}
