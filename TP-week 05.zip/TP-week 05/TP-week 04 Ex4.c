#include <stdio.h>
#include <string.h>
#include <ctype.h>
int main (){
    char w[20];
    int l,i;
    int p=1;
    printf("Input a string:");
    scanf("%s",&w);
    l = strlen(w);
    for (i = 0; i < l / 2; i++) {
        if (tolower(w[i]) != tolower(w[l - i - 1])) {
            p = 0;
            break;
        }}

    if (p) {
        printf("The word %s is a palindrome\n", w);
    } else {
        printf("The word %s is not a palindrome\n", w);
    }}


