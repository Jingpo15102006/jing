#include <stdio.h>
int main(){
    int n1,n2,n3,n4;
    printf("Enter 4 number:");
    scanf("%d %d %d %d",&n1,&n2,&n3,&n4);

    if(n2>n1 && n3>n1 && n4>n1){
        printf("Among these 4 input numbers (%d, %d, %d and %d), the smallest is %d",n1,n2,n3,n4,n1);
    }else if(n1>n2 && n3>n2 && n4>n2){
        printf("Among these 4 input numbers (%d, %d, %d and %d), the smallest is %d",n1,n2,n3,n4,n2);
    }else if(n1>n3 && n2>n3 &&n4>n3){
        printf("Among these 4 input numbers (%d, %d, %d and %d), the smallest is %d",n1,n2,n3,n4,n3);
    }else {
        printf("Among these 4 input numbers (%d, %d, %d and %d), the smallest is %d",n1,n2,n3,n4,n4);
    }

}
