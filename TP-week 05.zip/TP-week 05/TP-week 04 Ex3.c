#include <stdio.h>
#include <string.h>

int main(){
   char p1[50];
   char p2[50];
   printf("Enter option (rock_paper_scissor) player 1:");
   scanf("%s",&p1);
   printf("Enter option (rock_paper_scissor) player 2:");
   scanf("%s",&p2);

   if(strcmp(p1,"rock")==0 && strcmp(p2,"scissor")==0
      || strcmp(p1,"paper")==0 && strcmp(p2,"rock")==0
      || strcmp(p1, "scissor")==0 && strcmp(p2,"paper")==0){
      printf("The player 1 won the player 2 because %s win %s",p1,p2);

   }else if (strcmp(p2,"rock")==0 && strcmp(p1,"scissor")==0
             || strcmp(p2,"paper")==0 && strcmp(p1,"rock")==0
             || strcmp(p2, "scissor")==0 && strcmp(p1,"paper")==0){
      printf("The player 2 won the player 1 because %s win %s",p2,p1);
   }else {
      printf("The player 1 & 2 are equal because they have the same %s ", p1);
   }
}
