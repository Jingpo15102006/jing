#include <stdio.h>
#include <string.h>
int main() {
    int y ,m, d ;

    printf("Enter a date (yyyy-mm-dd): ");
    scanf("%d %d %d",&y,&m,&d);

    if( m<=12 && d<=31){
        if(m==2 ){
            if(y%4==0 && d<=29 || y%4!=0&& d<=28){
                printf("The given date: %d-%d-%d is valid date\n",y,m,d);
            }else{
                 printf("The given date: %d-%d-%d is notvalid\n",y,m,d);
            }
        }else if (m==4 ||m==6 ||m==9 || m==11){
            if(d<=30){
                printf("The given date: %d-%d-%d is valid date\n",y,m,d);
            }else {
                printf("The given date: %d-%d-%d is notvalid\n",y,m,d);
            }

        }else if(m==1 ||m==3||m==5||m==7|| m==8||m==11||m==10 ||m==12){
            if(d<=31){
                 printf("The given date: %d-%d-%d is valid date\n",y,m,d);
            }else{
                printf("The given date: %d-%d-%d is notvalid\n",y,m,d);
            }
        }

    } else {
        printf("The given date: %d-%d-%d is notvalid\n",y,m,d);
    }
 }
